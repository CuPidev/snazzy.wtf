#pragma once

extern unsigned char skeet[];
extern unsigned char cod[];
extern unsigned char bameware[];
extern unsigned char flick[];
extern unsigned char snazzy[];
extern unsigned char snazzy2[];
extern unsigned char bucket[];